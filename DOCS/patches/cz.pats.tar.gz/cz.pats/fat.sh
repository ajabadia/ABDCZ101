 Fat S/H  -  This is a nice FAT sample & hold patch.
 -------

Line Select 1+1 (Or use 1+2 depending on what you like better)
Detune: -  Octave: 0  Note: 00  Fine: 13
Vibrato: Wave 4  Delay: 00  Rate: 40  Depth: 99
Octave: Range -1

DCO1: Waveform First:5  Second:5
      Step1- Rate:50  Level:00  SUS
      Step2 to Step7- Rate:50  Level:00        Step8- Rate:50  Level:00
END

DCW1: Key Follow: 0
      Step1- Rate:99  Level:99  SUS
      Step2 to Step7- Rate:50  Level:00        Step8- Rate:50  Level:00
END
 DCA1: Key Follow: 0
      Step1- Rate:99  Level:99  SUS
      Step2 to Step7- Rate:50  Level:00        Step8- Rate:50  Level:00
END
    DC02: Waveform First:1  Second: 0
      Step1- Rate:50  Level:00  SUS
      Step2 to Step7- Rate:50  Level:00        Step8- Rate:50  Level:00
END

DCW2: Key Follow: 0
      Step1- Rate:99  Level:99  SUS
      Step2 to Step7- Rate:50  Level:00        Step8- Rate:50  Level:00
END
 DCA2: Key Follow: 0
      Step1- Rate:99  Level:99  SUS
      Step2 to Step7- Rate:50  Level:00        Step8- Rate:50  Level:00
END

